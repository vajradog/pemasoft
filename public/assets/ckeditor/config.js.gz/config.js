CKEDITOR.config.toolbar= [
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ], items: [ 'Bold','-', 'Italic','-', 'Underline' ] },

    { name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ], items: [ 'NumberedList', 'BulletedList', '-','JustifyLeft', 'JustifyCenter', 'JustifyRight' ] },

    { name: 'links', items: [ 'Link', 'Unlink' ] },

    { name: 'insert', items: [ 'Image' ] },

    { name: 'styles', items: [ 'Styles', 'Format', 'Font', 'FontSize' ] },

   
  ]
;
